
# README - Proyecto Final MIPS 32 bits (Fase 4)

## Descripción general
Este proyecto implementa un procesador MIPS de 32 bits con arquitectura segmentada en 5 etapas (IF, ID, EX, MEM, WB), capaz de ejecutar instrucciones tipo R, I y J. En esta última fase, se ejecuta el algoritmo de búsqueda binaria mediante un programa en ensamblador MIPS cargado en la memoria de instrucciones.

## Contenido del repositorio / entregable

### 1. Archivos Verilog (.v)
Módulos principales del procesador:
- DatapathV1.v
- UnidadControl.v
- PC.v
- add4.v
- BancoRegistros.v
- ALU.v
- ALUControl.v
- memoriaInstrucciones.v
- memoriaDatos.v
- multiplexor.v
- IF_ID.v, ID_EX.v, EX_MEM.v, MEM_WB.v

### 2. Archivos de prueba y ensamblador
- busqueda_binaria.asm
- deco_asm_binario.py
- binario_prueba.txt
- datos.txt

### 3. Reporte PDF
- Reporte_Fase_4.pdf

## Instrucciones de uso

### Paso 1: Editar/validar el código ASM
Editar busqueda_binaria.asm para incluir el algoritmo deseado.

### Paso 2: Convertir ASM a binario
Ejecutar el script Python:
    python deco_asm_binario.py
Seleccionar el archivo .asm y se generará binario_prueba.txt.

### Paso 3: Precargar en memoria
- Cargar binario_prueba.txt en memoriaInstrucciones.v
- Cargar datos.txt en memoriaDatos.v

### Paso 4: Simulación
Simular DatapathV1.v en ModelSim o cualquier otro simulador Verilog.

## Autores
- Humberto de Jesús Peña Dueñas
- Karla Rebeca Hernández Elizarrarás
- Elizabeth Arroyo Moreno

Ingeniería en Computación - CUCEI
Mayo 2025
