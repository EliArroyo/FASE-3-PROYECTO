import customtkinter as ctk
from tkinter import filedialog, messagebox

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

FuncionBinario = {
    "AND": "100100",
    "NOP": "000000",
    "ADD": "100000",
    "OR": "100101",
    "SUB": "100010",
    "SLT": "101010",
    "SW": "101011",
    "LW": "100011",
    "J": "000010",
    "ADDI": "001000",
    "BNE": "000101",
    "BEQ": "000100",
    "SLTI": "001010",
    "SLL": "000000",
    "SRL": "000010",
    "MUL": "011000",
    "DIV": "011010"
}

tipoInstruccion = {
    "AND": "R",
    "NOP": "R",
    "ADD": "R",
    "OR": "R",
    "SUB": "R",
    "SLT": "R",
    "SW": "I",
    "LW": "I",
    "J": "J",
    "ADDI": "I",
    "BNE": "I",
    "BEQ": "I",
    "SLTI": "I",
    "SLL": "R",
    "SRL": "R",
    "MUL": "R",
    "DIV": "R"
}

def instruccion_a_binario(numero):
    return f"{int(numero):05b}"

def seleccionar_archivo():
    archivo = filedialog.askopenfilename(filetypes=[("Archivos ASM", "*.asm")])
    if archivo:
        entry_path.delete(0, ctk.END)
        entry_path.insert(0, archivo)
        mostrar_contenido(archivo)

def mostrar_contenido(ruta):
    try:
        with open(ruta, "r", encoding="utf-8") as f:
            contenido = f.read()
        text_area.delete("1.0", ctk.END)
        text_area.insert(ctk.END, contenido)
    except Exception as e:
        messagebox.showerror("Error", f"No se pudo leer el archivo\n{e}")

def convertir_a_binario():
    ruta = entry_path.get()
    if not ruta:
        messagebox.showwarning("Atención", "Selecciona un archivo primero")
        return

    try:
        with open(ruta, "r", encoding="utf-8") as f:
            lineas = f.readlines()

        resultados = []

        for linea in lineas:
            linea = linea.strip()
            if not linea:
                continue
            partes = linea.split()
            instruccion = partes[0].upper()
            if instruccion in tipoInstruccion:
                tipo = tipoInstruccion[instruccion]
                funct = FuncionBinario[instruccion]

                if tipo == "R":
                    if funct == "000000":
                        cadena = "00000000000000000000000000000000"
                    else:
                        rd = partes[1].replace("$", "")
                        rs = partes[2].replace("$", "")
                        rt = partes[3].replace("$", "")
                        op = "000000"
                        shamt = "00000"
                        RD = instruccion_a_binario(rd)
                        RS = instruccion_a_binario(rs)
                        RT = instruccion_a_binario(rt)
                        cadena = op + RS + RT + RD + shamt + funct

                elif tipo == "I":
                    rs = partes[1].replace("$", "")
                    rt = partes[2].replace("$", "")
                    offset = partes[3].replace("#", "")
                    op = funct
                    RS = instruccion_a_binario(rs)
                    RT = instruccion_a_binario(rt)
                    Offset = f"{int(offset):016b}"
                    cadena = op + RS + RT + Offset

                elif tipo == "J":
                    index = partes[1].replace("#", "")
                    op = funct
                    Index = f"{int(index):026b}"
                    cadena = op + Index

                partes_bin = [cadena[i:i+8] for i in range(0, 32, 8)]
                resultado_final = "_".join(partes_bin)
                resultados.append(resultado_final)

        ruta_salida = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Archivo Binario", "*.txt")])
        if ruta_salida:
            with open(ruta_salida, "w", encoding="utf-8") as f:
                f.write("\n".join(resultados))
            messagebox.showinfo("Éxito", f"Archivo binario guardado en:\n{ruta_salida}")

    except Exception as e:
        messagebox.showerror("Error", f"No se pudo procesar el archivo\n{e}")

# -------------------- UI --------------------

root = ctk.CTk()
root.title("🛠️ Conversor ASM a Binario")
root.geometry("600x500")

frame = ctk.CTkFrame(master=root)
frame.pack(padx=20, pady=20, fill="both", expand=True)

label = ctk.CTkLabel(frame, text="Selecciona un archivo ASM", font=ctk.CTkFont(size=16))
label.pack(pady=(10, 5))

entry_path = ctk.CTkEntry(frame, width=400)
entry_path.pack(pady=5)

btn_select = ctk.CTkButton(frame, text="📂 Buscar", command=seleccionar_archivo)
btn_select.pack(pady=5)

text_area = ctk.CTkTextbox(frame, height=200)
text_area.pack(padx=10, pady=10, fill="both", expand=True)

btn_convert = ctk.CTkButton(frame, text="🔁 Convertir a Binario", command=convertir_a_binario)
btn_convert.pack(pady=10)

root.mainloop()
